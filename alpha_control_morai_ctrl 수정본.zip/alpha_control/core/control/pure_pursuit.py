# -*- coding: utf-8 -*-
"""ROS-independent Pure Pursuit lateral controller.

This controller supports both forward and reverse reference trajectory segments.
For reverse tracking, the lookahead point is evaluated in the vehicle's rearward
tracking frame by flipping the local x/y coordinates.
"""

import math
from dataclasses import dataclass
from typing import List, Optional, Tuple

from core.common.geometry import angle_diff, clamp, normalize_angle
from core.common.types import RefTrajectoryPoint


@dataclass
class PurePursuitResult:
    steering_rad: float
    nearest_index: int
    target_index: int
    lookahead_distance: float
    lateral_error: float
    heading_error: float
    target_x: float
    target_y: float
    target_yaw: float
    gear: int


class PurePursuitController:
    def __init__(self,
                 wheel_base: float = 2.70,
                 max_steer_deg: float = 35.0,
                 min_lookahead: float = 0.80,
                 max_lookahead: float = 2.50,
                 lookahead_gain: float = 0.85):
        self.wheel_base = float(wheel_base)
        self.max_steer = math.radians(float(max_steer_deg))
        self.min_lookahead = float(min_lookahead)
        self.max_lookahead = float(max_lookahead)
        self.lookahead_gain = float(lookahead_gain)

    def compute_lookahead(self, speed_abs: float) -> float:
        ld = self.min_lookahead + self.lookahead_gain * abs(float(speed_abs))
        return clamp(ld, self.min_lookahead, self.max_lookahead)

    @staticmethod
    def nearest_index(ref: List[RefTrajectoryPoint], x: float, y: float, start_index: int = 0) -> int:
        if not ref:
            return 0
        start_index = max(0, min(int(start_index), len(ref) - 1))
        # Parking execution should be monotonic along the reference path.
        # Searching backward can make the tracker stick at the last forward
        # stop point and never enter the reverse segment after gear change.
        begin = max(0, start_index)
        best_i = begin
        best_d2 = float("inf")
        for i in range(begin, len(ref)):
            dx = ref[i].x - x
            dy = ref[i].y - y
            d2 = dx * dx + dy * dy
            if d2 < best_d2:
                best_d2 = d2
                best_i = i
            # Stop after passing the nearest point by a reasonable margin.
            if i > best_i + 80:
                break
        return best_i

    @staticmethod
    def target_index_from_lookahead(ref: List[RefTrajectoryPoint], nearest: int, lookahead: float, gear: int) -> int:
        if not ref:
            return 0
        nearest = max(0, min(int(nearest), len(ref) - 1))
        base_s = ref[nearest].s
        for i in range(nearest + 1, len(ref)):
            # Do not look through a gear-change too far. Parking maneuvers need
            # the pull-up and reverse-in segment to be tracked separately.
            if ref[i].gear != gear and i > nearest + 3:
                return max(nearest + 1, i - 1)
            if abs(ref[i].s - base_s) >= lookahead:
                return i
        return len(ref) - 1

    def compute(self,
                ref: List[RefTrajectoryPoint],
                x: float,
                y: float,
                yaw: float,
                speed: float,
                previous_nearest_index: int = 0) -> Optional[PurePursuitResult]:
        if not ref:
            return None

        nearest = self.nearest_index(ref, x, y, previous_nearest_index)
        gear = 1 if ref[nearest].gear >= 0 else -1
        lookahead = self.compute_lookahead(abs(speed))
        target = self.target_index_from_lookahead(ref, nearest, lookahead, gear)
        target_pt = ref[target]

        dx = target_pt.x - x
        dy = target_pt.y - y

        # Use the motion-direction frame for Pure Pursuit. For reverse motion,
        # the vehicle moves along yaw + pi, but the bicycle model still evolves
        # using signed rear-axle speed v and front steering angle.
        motion_yaw = yaw if gear >= 0 else normalize_angle(yaw + math.pi)
        c = math.cos(-motion_yaw)
        s = math.sin(-motion_yaw)
        local_x = c * dx - s * dy
        local_y = s * dx + c * dy

        ld = max(math.hypot(local_x, local_y), 1e-6)
        curvature_motion = 2.0 * local_y / max(ld * ld, 1e-6)
        curvature_signed = float(gear) * curvature_motion
        steering = math.atan(self.wheel_base * curvature_signed)
        steering = clamp(steering, -self.max_steer, self.max_steer)

        nearest_pt = ref[nearest]
        ndx = x - nearest_pt.x
        ndy = y - nearest_pt.y
        # Lateral error in reference yaw frame. Positive means vehicle is left of reference heading.
        lateral_error = -math.sin(nearest_pt.yaw) * ndx + math.cos(nearest_pt.yaw) * ndy
        heading_error = angle_diff(yaw, nearest_pt.yaw)

        return PurePursuitResult(
            steering_rad=steering,
            nearest_index=nearest,
            target_index=target,
            lookahead_distance=lookahead,
            lateral_error=lateral_error,
            heading_error=heading_error,
            target_x=target_pt.x,
            target_y=target_pt.y,
            target_yaw=target_pt.yaw,
            gear=gear,
        )
