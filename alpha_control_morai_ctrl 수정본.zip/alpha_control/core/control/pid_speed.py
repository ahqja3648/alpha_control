# -*- coding: utf-8 -*-
"""Simple ROS-independent PID speed controller."""

from dataclasses import dataclass
from core.common.geometry import clamp


@dataclass
class PIDResult:
    accel_cmd: float
    brake_cmd: float
    raw_output: float
    error: float


class PIDSpeedController:
    def __init__(self,
                 kp: float = 0.9,
                 ki: float = 0.04,
                 kd: float = 0.02,
                 max_accel_cmd: float = 1.0,
                 max_brake_cmd: float = 1.0,
                 integral_limit: float = 2.0,
                 deadband: float = 0.02):
        self.kp = float(kp)
        self.ki = float(ki)
        self.kd = float(kd)
        self.max_accel_cmd = float(max_accel_cmd)
        self.max_brake_cmd = float(max_brake_cmd)
        self.integral_limit = float(integral_limit)
        self.deadband = float(deadband)
        self.integral = 0.0
        self.prev_error = 0.0
        self.has_prev = False

    def reset(self):
        self.integral = 0.0
        self.prev_error = 0.0
        self.has_prev = False

    def step(self, target_speed: float, current_speed: float, dt: float) -> PIDResult:
        dt = max(float(dt), 1e-3)
        error = float(target_speed) - float(current_speed)
        if abs(error) < self.deadband:
            error = 0.0

        self.integral += error * dt
        self.integral = clamp(self.integral, -self.integral_limit, self.integral_limit)

        if self.has_prev:
            derivative = (error - self.prev_error) / dt
        else:
            derivative = 0.0
            self.has_prev = True
        self.prev_error = error

        raw = self.kp * error + self.ki * self.integral + self.kd * derivative
        if raw >= 0.0:
            accel = clamp(raw, 0.0, self.max_accel_cmd)
            brake = 0.0
        else:
            accel = 0.0
            brake = clamp(-raw, 0.0, self.max_brake_cmd)

        return PIDResult(accel_cmd=accel, brake_cmd=brake, raw_output=raw, error=error)
