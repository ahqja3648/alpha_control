# -*- coding: utf-8 -*-
"""Reference trajectory tracking: Pure Pursuit steering + PID speed."""

from dataclasses import dataclass
from typing import List, Optional

from core.common.types import RefTrajectoryPoint
from .pid_speed import PIDSpeedController
from .pure_pursuit import PurePursuitController, PurePursuitResult


@dataclass
class TrackingResult:
    target_speed: float
    current_speed: float
    accel_cmd: float
    brake_cmd: float
    steering_rad: float
    gear: int
    nearest_index: int
    target_index: int
    lookahead_distance: float
    lateral_error: float
    heading_error: float
    target_x: float
    target_y: float
    target_yaw: float
    goal_reached: bool


class ReferenceTracker:
    def __init__(self,
                 pure_pursuit: PurePursuitController,
                 speed_pid: PIDSpeedController,
                 goal_dist_tolerance: float = 0.35,
                 goal_speed_tolerance: float = 0.08,
                 gear_switch_speed_tolerance: float = 0.12,
                 gear_switch_scan_points: int = 20):
        self.pp = pure_pursuit
        self.pid = speed_pid
        self.goal_dist_tolerance = float(goal_dist_tolerance)
        self.goal_speed_tolerance = float(goal_speed_tolerance)
        self.gear_switch_speed_tolerance = float(gear_switch_speed_tolerance)
        self.gear_switch_scan_points = int(gear_switch_scan_points)
        self.nearest_index = 0

    def reset(self):
        self.nearest_index = 0
        self.pid.reset()

    def update(self,
               ref: List[RefTrajectoryPoint],
               x: float,
               y: float,
               yaw: float,
               current_speed: float,
               dt: float) -> Optional[TrackingResult]:
        if not ref:
            return None

        pp_res: PurePursuitResult = self.pp.compute(
            ref, x, y, yaw, current_speed, self.nearest_index
        )
        if pp_res is None:
            return None

        # Gear-change handling. If the reference has a zero-speed stop point
        # followed by the opposite gear and the vehicle is already nearly
        # stopped, advance the tracking index into the next segment. Without
        # this, the controller can remain forever on the final D point with
        # target_speed=0 and never request R.
        switch_idx = None
        end_scan = min(len(ref), pp_res.nearest_index + max(2, self.gear_switch_scan_points))
        for i in range(pp_res.nearest_index + 1, end_scan):
            if ref[i].gear != pp_res.gear:
                switch_idx = i
                break
        if (switch_idx is not None
                and abs(ref[pp_res.nearest_index].v) < 0.05
                and abs(current_speed) <= self.gear_switch_speed_tolerance):
            self.nearest_index = switch_idx
            pp_res = self.pp.compute(ref, x, y, yaw, current_speed, self.nearest_index)
            if pp_res is None:
                return None

        self.nearest_index = pp_res.nearest_index

        nearest_gear = 1 if pp_res.gear >= 0 else -1
        target_pt = ref[pp_res.target_index]
        target_gear = 1 if target_pt.gear >= 0 else -1
        target_speed = target_pt.v

        # If the lookahead target already belongs to the next gear segment, do
        # not keep commanding the old gear forever. At a gear boundary, first
        # command a full stop while the vehicle is still moving. Once speed is
        # low enough, switch the tracking index into the next segment and let
        # Pure Pursuit recompute with the new gear frame. This fixes the case
        # seen in MORAI logs: nearest/target=88/91, gear=D, target_v<0.
        if target_gear != nearest_gear:
            if abs(current_speed) > self.gear_switch_speed_tolerance:
                gear = nearest_gear
                target_speed = 0.0
                pid_res = self.pid.step(0.0, abs(current_speed), dt)
                pid_res.accel_cmd = 0.0
                pid_res.brake_cmd = 1.0
            else:
                self.nearest_index = pp_res.target_index
                pp_res = self.pp.compute(ref, x, y, yaw, current_speed, self.nearest_index)
                if pp_res is None:
                    return None
                self.nearest_index = pp_res.nearest_index
                target_pt = ref[pp_res.target_index]
                target_speed = target_pt.v
                gear = 1 if target_pt.gear >= 0 else -1
                target_speed_in_gear = abs(target_speed)
                current_speed_in_gear = float(gear) * current_speed
                pid_res = self.pid.step(target_speed_in_gear, current_speed_in_gear, dt)
        else:
            gear = nearest_gear
            # PID works in the current gear frame. This way accel_cmd means
            # "accelerate in the selected gear" for both D and R.
            target_speed_in_gear = abs(target_speed)
            current_speed_in_gear = float(gear) * current_speed
            pid_res = self.pid.step(target_speed_in_gear, current_speed_in_gear, dt)

        last = ref[-1]
        dx = last.x - x
        dy = last.y - y
        dist_to_goal = (dx * dx + dy * dy) ** 0.5
        goal_reached = dist_to_goal <= self.goal_dist_tolerance and abs(current_speed) <= self.goal_speed_tolerance

        if goal_reached:
            pid_res.accel_cmd = 0.0
            pid_res.brake_cmd = 1.0
            target_speed = 0.0

        return TrackingResult(
            target_speed=target_speed,
            current_speed=current_speed,
            accel_cmd=pid_res.accel_cmd,
            brake_cmd=pid_res.brake_cmd,
            steering_rad=pp_res.steering_rad,
            gear=gear,
            nearest_index=pp_res.nearest_index,
            target_index=pp_res.target_index,
            lookahead_distance=pp_res.lookahead_distance,
            lateral_error=pp_res.lateral_error,
            heading_error=pp_res.heading_error,
            target_x=pp_res.target_x,
            target_y=pp_res.target_y,
            target_yaw=pp_res.target_yaw,
            goal_reached=goal_reached,
        )
