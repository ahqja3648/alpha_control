# -*- coding: utf-8 -*-
"""Geometric rear-axle seed path for RViz demos.

This is used only as a fallback if the coarse Hybrid A* search fails under very
strict 2.2 m x 4.4 m parking-slot constraints. It keeps the same data interface
as Hybrid A*: a raw path of DensePathPoint objects with direction and steering.
"""

import math
from typing import List, Tuple

from core.common.geometry import normalize_angle
from core.common.types import DensePathPoint, PlannerConfig


def make_rear_axle_seed_path(start: Tuple[float, float, float],
                             goal: Tuple[float, float, float],
                             cfg: PlannerConfig) -> List[DensePathPoint]:
    target_x, _, _ = goal
    start_x, start_y, start_yaw = start
    goal_x, goal_y, goal_yaw = goal
    pts: List[DensePathPoint] = []

    def append(x, y, yaw, direction, steer):
        pts.append(DensePathPoint(float(x), float(y), normalize_angle(float(yaw)), int(direction), float(steer)))

    # 1) Forward pull-up in the aisle.
    pull_x = target_x + 3.95
    pull_y = start_y
    step = 0.10
    n = max(2, int(abs(pull_x - start_x) / step))
    for i in range(n + 1):
        t = float(i) / float(n)
        x = start_x + t * (pull_x - start_x)
        y = start_y + t * (pull_y - start_y)
        append(x, y, start_yaw, +1, 0.0)

    # 2) Reverse arc into the parking slot.
    x, y, yaw = pull_x, pull_y, start_yaw
    steer = cfg.max_steer
    ds = -0.05
    guard = 0
    while yaw > goal_yaw + math.radians(2.0) and guard < 360:
        x += math.cos(yaw) * ds
        y += math.sin(yaw) * ds
        yaw = normalize_angle(yaw + ds / cfg.wheel_base * math.tan(steer))
        append(x, y, yaw, -1, steer)
        guard += 1

    # 3) Smooth correction from the end of the arc to exact rear-axle goal pose.
    if pts:
        sx, sy, syaw = pts[-1].x, pts[-1].y, pts[-1].yaw
    else:
        sx, sy, syaw = start
    dist = math.hypot(goal_x - sx, goal_y - sy)
    n = max(2, int(dist / 0.08))
    for i in range(1, n + 1):
        t = float(i) / float(n)
        u = t * t * (3.0 - 2.0 * t)
        x = sx + u * (goal_x - sx)
        y = sy + u * (goal_y - sy)
        yaw = normalize_angle(syaw + u * normalize_angle(goal_yaw - syaw))
        append(x, y, yaw, -1, 0.0)

    # A few stop points.
    for _ in range(5):
        append(goal_x, goal_y, goal_yaw, -1, 0.0)

    return pts
