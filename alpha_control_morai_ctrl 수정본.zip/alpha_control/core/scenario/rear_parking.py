# -*- coding: utf-8 -*-
"""Default rear-parking scenario used before perception is completed."""

import math
from typing import List, Tuple

from core.common.types import RectObstacle
from core.planning.drivable_area import DrivableArea


# Perpendicular parking row. Slot width = 2.2 m.
DEFAULT_SLOT_WIDTH = 2.20
DEFAULT_SLOT_LENGTH = 4.40
DEFAULT_SLOT_CENTERS = [0.0, 2.20, 4.40, 6.60, 8.80, 11.00]
TARGET_SLOT_INDEX = 2
TARGET_SLOT_X = DEFAULT_SLOT_CENTERS[TARGET_SLOT_INDEX]


def make_rear_parking_scenario() -> Tuple[List[RectObstacle], DrivableArea, Tuple[float, float, float], Tuple[float, float, float]]:
    obstacles: List[RectObstacle] = []
    # Parked vehicle bodies are represented by their body center, not rear axle.
    slot_center_y = DEFAULT_SLOT_LENGTH * 0.5 + 0.15
    parked_yaw = math.radians(-90.0)
    target_x = TARGET_SLOT_X
    parked_vehicle_length = 4.00
    parked_vehicle_width = 1.85

    for i, sx in enumerate(DEFAULT_SLOT_CENTERS):
        if abs(sx - target_x) < 1e-6:
            continue
        obstacles.append(RectObstacle(sx, slot_center_y, parked_yaw, parked_vehicle_length, parked_vehicle_width, "parked_car_%02d" % (i + 1)))

    # Rear curb and side boundaries are physical obstacles.
    obstacles.append(RectObstacle(5.40, DEFAULT_SLOT_LENGTH + 0.18, 0.0, 14.0, 0.16, "rear_curb_wall"))
    obstacles.append(RectObstacle(-1.58, -0.25, 0.0, 0.12, 10.4, "left_boundary"))
    obstacles.append(RectObstacle(12.38, -0.25, 0.0, 0.12, 10.4, "right_boundary"))

    drivable_area = DrivableArea.default_rear_parking_area()

    # All ego poses are rear axle center.
    # Start is in the aisle, close to the parked row and slightly behind the target slot.
    start = (target_x - 2.80, -1.25, math.radians(0.0))

    # Rear parking goal: yaw=-90 deg, front faces the aisle.
    # For rear-axle origin, rear bumper y = rear_axle_y + rear_overhang.
    # With rear_overhang=0.75, this keeps the body inside the 4.4 m slot.
    goal = (target_x, DEFAULT_SLOT_LENGTH - 0.75 - 0.10, math.radians(-90.0))
    return obstacles, drivable_area, start, goal
