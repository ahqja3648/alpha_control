# -*- coding: utf-8 -*-
"""Manual drivable-area hard constraint.

The planner should treat lane/aisle boundaries as hard constraints, not just
visual guide lines. Later, camera/BEV lane detection can replace the polygon
source while keeping this interface unchanged.
"""

import os
from typing import List, Optional, Tuple

from core.common.geometry import (
    convex_polygons_intersect,
    point_in_polygon,
    sample_polygon_boundary,
)


class DrivableArea:
    """
    Valid vehicle pose condition:
      1) inflated vehicle footprint must be inside outer_polygon
      2) inflated vehicle footprint must not overlap forbidden_polygons
    """

    def __init__(self,
                 outer_polygon: List[Tuple[float, float]],
                 forbidden_polygons: Optional[List[Tuple[str, List[Tuple[float, float]]]]] = None,
                 name: str = "manual_drivable_area"):
        self.name = name
        self.outer_polygon = [(float(x), float(y)) for x, y in outer_polygon]
        self.forbidden_polygons = []
        for item in (forbidden_polygons or []):
            name_i, poly = item
            self.forbidden_polygons.append((name_i, [(float(x), float(y)) for x, y in poly]))

    @staticmethod
    def default_rear_parking_area() -> "DrivableArea":
        # T-shaped allowed area for a 2.2 m x 4.4 m perpendicular parking slot.
        # The allowed area is the aisle plus the target slot only.
        # Everything else is treated as non-drivable even if no physical wall exists.
        target_x = 4.40
        slot_w = 2.20
        slot_l = 4.40
        slot_x_min = target_x - 0.5 * slot_w
        slot_x_max = target_x + 0.5 * slot_w
        aisle_y_min = -3.30
        slot_y_min = 0.00
        slot_y_max = slot_l
        outer = [
            (-1.50, aisle_y_min),
            (12.30, aisle_y_min),
            (12.30, slot_y_min),
            (slot_x_max, slot_y_min),
            (slot_x_max, slot_y_max),
            (slot_x_min, slot_y_max),
            (slot_x_min, slot_y_min),
            (-1.50, slot_y_min),
        ]
        forbidden = [
            ("opposite_side_no_drive_zone", [
                (-1.50, -5.50), (12.30, -5.50), (12.30, aisle_y_min), (-1.50, aisle_y_min)
            ]),
            ("left_parking_slots_no_drive_zone", [
                (-1.50, slot_y_min), (slot_x_min, slot_y_min), (slot_x_min, slot_y_max), (-1.50, slot_y_max)
            ]),
            ("right_parking_slots_no_drive_zone", [
                (slot_x_max, slot_y_min), (12.30, slot_y_min), (12.30, slot_y_max), (slot_x_max, slot_y_max)
            ]),
        ]
        return DrivableArea(outer, forbidden)

    @staticmethod
    def from_yaml(path: str) -> "DrivableArea":
        try:
            import yaml
        except ImportError as exc:
            raise RuntimeError("PyYAML is required for loading a YAML drivable area file") from exc

        with open(path, "r") as f:
            cfg = yaml.safe_load(f)
        da = cfg.get("drivable_area", cfg)
        outer = da["outer_polygon"]
        forbidden = []
        for item in da.get("forbidden_polygons", []):
            forbidden.append((item.get("name", "forbidden"), item["points"]))
        return DrivableArea(outer, forbidden, name=os.path.basename(path))

    def footprint_inside_outer(self, footprint: List[Tuple[float, float]]) -> bool:
        # Corners alone are insufficient for concave polygons, so sample edges too.
        for x, y in sample_polygon_boundary(footprint, samples_per_edge=5):
            if not point_in_polygon(x, y, self.outer_polygon):
                return False
        return True

    def footprint_hits_forbidden(self, footprint: List[Tuple[float, float]]) -> bool:
        for _, poly in self.forbidden_polygons:
            # Current forbidden polygons are rectangles, so SAT is valid.
            if convex_polygons_intersect(footprint, poly):
                return True
            for x, y in sample_polygon_boundary(footprint, samples_per_edge=2):
                if point_in_polygon(x, y, poly):
                    return True
        return False

    def is_footprint_valid(self, footprint: List[Tuple[float, float]]) -> bool:
        return self.footprint_inside_outer(footprint) and not self.footprint_hits_forbidden(footprint)
