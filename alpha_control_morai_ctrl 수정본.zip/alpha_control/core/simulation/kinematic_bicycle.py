# -*- coding: utf-8 -*-
"""Rear-axle-origin kinematic bicycle simulator.

State origin:
  x, y : rear axle center
  yaw  : vehicle heading / base_link x-axis
  v    : signed rear-axle speed. forward positive, reverse negative.
"""

import math
from dataclasses import dataclass

from core.common.geometry import clamp, normalize_angle


@dataclass
class VehicleState:
    x: float
    y: float
    yaw: float
    v: float = 0.0


class RearAxleBicycleSimulator:
    def __init__(self, wheel_base: float = 2.70, accel_limit: float = 0.80):
        self.wheel_base = float(wheel_base)
        self.accel_limit = abs(float(accel_limit))
        self.state = VehicleState(0.0, 0.0, 0.0, 0.0)

    def reset(self, x: float, y: float, yaw: float, v: float = 0.0):
        self.state = VehicleState(float(x), float(y), normalize_angle(float(yaw)), float(v))

    def step(self, steering_rad: float, gear: int, accel_cmd: float, brake_cmd: float, dt: float):
        dt = max(float(dt), 1e-4)
        gear_sign = 1.0 if int(gear) >= 0 else -1.0
        accel_cmd = clamp(float(accel_cmd), 0.0, 1.0)
        brake_cmd = clamp(float(brake_cmd), 0.0, 1.0)

        # Convert accel/brake command into signed speed dynamics.
        # accel_cmd increases speed magnitude in selected gear.
        # brake_cmd reduces speed magnitude toward zero.
        v_in_gear = gear_sign * self.state.v
        v_in_gear += (accel_cmd * self.accel_limit - brake_cmd * self.accel_limit) * dt
        v_in_gear = max(0.0, v_in_gear)
        self.state.v = gear_sign * v_in_gear

        # Rear-axle kinematic bicycle model.
        self.state.x += self.state.v * math.cos(self.state.yaw) * dt
        self.state.y += self.state.v * math.sin(self.state.yaw) * dt
        self.state.yaw = normalize_angle(
            self.state.yaw + self.state.v / self.wheel_base * math.tan(float(steering_rad)) * dt
        )
        return self.state
