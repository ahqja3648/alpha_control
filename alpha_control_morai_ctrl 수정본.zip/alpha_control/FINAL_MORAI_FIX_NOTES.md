# alpha_control final MORAI parking fix notes

This package keeps the full `alpha_control` project structure and applies the final MORAI fixes discussed in the conversation.

## Final assumptions

- `/Ego_topic.position` is used as rear-axle pose.
- Parking slot size: width 2.2 m, length 4.4 m.
- Ego vehicle geometry:
  - vehicle_length: 4.43 m
  - vehicle_width: 1.825 m
  - wheel_base: 2.70 m
  - rear_overhang/front_overhang: 0.865 m
- Fixed MORAI scenario poses are stored in `core/scenario/morai_fixed_pose.py` and `config/morai_fixed_parking_params.yaml`.

## Key final change

`nodes/morai_adapter_node.py` now publishes MORAI CtrlCmd with:

```text
longlCmdType = 1
accel = PID accel command
brake = PID brake / safety brake
velocity = 0.0
acceleration = 0.0
```

Velocity mode (`longlCmdType=2`) is not used for parking control anymore because it caused the vehicle to keep creeping forward at stop and gear-switch points.

## Debug topics

Check these while running:

```bash
rostopic echo -n 1 /alpha_control/debug_summary
rostopic echo -n 1 /alpha_control/morai_adapter_debug
rostopic echo -n 5 /ctrl_cmd_0
```

Normal MORAI command in this final version should show:

```text
longlCmdType: 1
accel: 0.0~0.35 while moving
brake: 1.0 while stopping
velocity: 0.0
```

## Launch

```bash
roslaunch alpha_control parking_morai_fixed.launch
```

If steering direction is reversed:

```bash
roslaunch alpha_control parking_morai_fixed.launch invert_steer_sign:=false
```

If front_steer is treated as rad in your MORAI version:

```bash
roslaunch alpha_control parking_morai_fixed.launch front_steer_command_type:=rad
```
