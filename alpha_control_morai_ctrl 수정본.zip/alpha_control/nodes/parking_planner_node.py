#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ROS node wrapper for autonomous rear-parking planning.

This file should stay thin: read ROS params, call ROS-independent core modules,
and publish RViz/debug outputs. The actual planning logic is in core/.
"""

import math
import os
import sys
import traceback

# Allow imports from package root when this script is launched from nodes/.
PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from core.common.types import PlannerConfig
from core.planning.drivable_area import DrivableArea
from core.planning.hybrid_astar import HybridAStarPlanner
from core.scenario.rear_parking import DEFAULT_SLOT_CENTERS, make_rear_parking_scenario
from core.scenario.rear_axle_seed import make_rear_axle_seed_path
from core.trajectory.csv_export import write_ref_csv
from core.trajectory.reference_trajectory import ReferenceTrajectoryGenerator
from core.visualization.rviz_visualizer import RvizVisualizer


def load_config_from_ros_params(rospy) -> PlannerConfig:
    return PlannerConfig(
        min_x=rospy.get_param("~min_x", -1.6),
        max_x=rospy.get_param("~max_x", 12.4),
        min_y=rospy.get_param("~min_y", -5.5),
        max_y=rospy.get_param("~max_y", 4.8),
        xy_resolution=rospy.get_param("~xy_resolution", 0.35),
        yaw_resolution_deg=rospy.get_param("~yaw_resolution_deg", 10.0),
        primitive_length=rospy.get_param("~primitive_length", 0.70),
        integration_step=rospy.get_param("~integration_step", 0.10),
        steer_sample_count=rospy.get_param("~steer_sample_count", 7),
        max_iterations=rospy.get_param("~max_iterations", 90000),
        ref_ds=rospy.get_param("~ref_ds", 0.12),
        max_ref_speed=rospy.get_param("~max_ref_speed", 0.65),
        min_segment_time=rospy.get_param("~min_segment_time", 2.0),
        wheel_base=rospy.get_param("~wheel_base", 2.70),
        front_overhang=rospy.get_param("~front_overhang", 0.75),
        rear_overhang=rospy.get_param("~rear_overhang", 0.75),
        vehicle_width=rospy.get_param("~vehicle_width", 1.85),
        max_steer_deg=rospy.get_param("~max_steer_deg", 35.0),
        collision_padding=rospy.get_param("~collision_padding", 0.035),
        drivable_padding=rospy.get_param("~drivable_padding", 0.025),
        slot_width=rospy.get_param("~slot_width", 2.20),
        slot_length=rospy.get_param("~slot_length", 4.40),
        goal_xy_tolerance=rospy.get_param("~goal_xy_tolerance", 0.45),
        goal_yaw_tolerance_deg=rospy.get_param("~goal_yaw_tolerance_deg", 14.0),
    )


def main():
    import rospy

    rospy.init_node("alpha_control_parking_planner", anonymous=False)

    from alpha_control.msg import RefTrajectory, RefTrajectoryPoint
    ref_traj_pub = rospy.Publisher("/alpha_control/ref_trajectory", RefTrajectory, queue_size=1, latch=True)

    cfg = load_config_from_ros_params(rospy)
    obstacles, default_area, start, goal = make_rear_parking_scenario()

    yaml_path = rospy.get_param("~drivable_area_yaml", "")
    if yaml_path:
        drivable_area = DrivableArea.from_yaml(yaml_path)
        rospy.loginfo("Loaded drivable area YAML: %s", yaml_path)
    else:
        drivable_area = default_area
        rospy.loginfo("Using built-in manual drivable area")

    # Optional external start/goal override.
    if rospy.get_param("~use_external_start_goal", False):
        sp = rospy.get_param("~start", [start[0], start[1], math.degrees(start[2])])
        gp = rospy.get_param("~goal", [goal[0], goal[1], math.degrees(goal[2])])
        start = (float(sp[0]), float(sp[1]), math.radians(float(sp[2])))
        goal = (float(gp[0]), float(gp[1]), math.radians(float(gp[2])))

    planner = HybridAStarPlanner(obstacles, drivable_area, cfg)
    viz = RvizVisualizer(planner, start, goal, slot_centers=DEFAULT_SLOT_CENTERS)
    rospy.sleep(0.8)
    viz.publish_static()

    visualize_every_n = int(rospy.get_param("~visualize_every_n", 8))
    animation_dt = float(rospy.get_param("~animation_dt", 0.02))

    def callback(*args):
        viz.publish_search_step(*args)
        if animation_dt > 0.0:
            rospy.sleep(animation_dt)

    try:
        rospy.loginfo("Hybrid A* planning started with drivable-area hard constraint")
        chain = planner.plan(start, goal, step_callback=callback, callback_every_n=visualize_every_n)
        if chain is None:
            rospy.logwarn("Hybrid A* planning failed under current strict constraints. Stats: %s", planner.last_stats)
            if rospy.get_param("~use_fallback_seed_on_fail", True):
                rospy.logwarn("Using rear-axle geometric seed path as fallback so RViz tracking demo can continue.")
                raw = make_rear_axle_seed_path(start, goal, cfg)
            else:
                rospy.logerr("Planning failed and fallback is disabled.")
                return
        else:
            raw = planner.chain_to_dense_path(chain)

        ref = ReferenceTrajectoryGenerator(cfg).generate(raw)
        csv_path = rospy.get_param("~ref_csv_path", os.path.expanduser("~/.ros/hybrid_astar_ref_traj.csv"))
        write_ref_csv(csv_path, ref)

        ref_msg = RefTrajectory()
        ref_msg.header.stamp = rospy.Time.now()
        ref_msg.header.frame_id = "map"
        for p in ref:
            pt = RefTrajectoryPoint()
            pt.t = p.t
            pt.x = p.x
            pt.y = p.y
            pt.yaw = p.yaw
            pt.s = p.s
            pt.v = p.v
            pt.a = p.a
            pt.curvature = p.curvature
            pt.steer = p.steer
            pt.gear = p.gear
            ref_msg.points.append(pt)
        ref_traj_pub.publish(ref_msg)

        viz.publish_raw_and_ref(raw, ref, csv_path)

        rospy.loginfo("Planning succeeded: raw=%d, ref=%d, stats=%s", len(raw), len(ref), planner.last_stats)
        rospy.loginfo("Published /alpha_control/ref_trajectory")
        rospy.loginfo("Reference trajectory CSV saved: %s", csv_path)
        rospy.spin()
    except Exception as exc:
        rospy.logerr("Exception: %s", str(exc))
        rospy.logerr(traceback.format_exc())


if __name__ == "__main__":
    main()
