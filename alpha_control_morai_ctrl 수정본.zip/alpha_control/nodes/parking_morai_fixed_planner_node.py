#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""One-shot MORAI parking planner for the measured cone-slot scenario.

This node uses the user's measured MORAI /Ego_topic poses:
  current pose, target pose, left obstacle, right obstacle.
The measured poses are treated as rear-axle-center poses by default, because
the user measured/provided all positions in the rear-axle coordinate convention.
"""

import math
import os
import sys
import traceback

import tf.transformations
from geometry_msgs.msg import PoseStamped

PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from core.common.types import PlannerConfig, RefTrajectoryPoint
from core.planning.hybrid_astar import HybridAStarPlanner
from core.scenario.morai_fixed_pose import (
    DEFAULT_SCENARIO,
    local_to_world,
    make_morai_fixed_pose_scenario,
    make_morai_fixed_seed_path,
)
from core.trajectory.csv_export import write_ref_csv
from core.trajectory.reference_trajectory import ReferenceTrajectoryGenerator
from core.visualization.rviz_visualizer import RvizVisualizer


def load_config_from_ros_params(rospy) -> PlannerConfig:
    # Bounds are overwritten after the scenario is generated, but keep defaults sane.
    return PlannerConfig(
        min_x=rospy.get_param("~min_x", 6.0),
        max_x=rospy.get_param("~max_x", 18.5),
        min_y=rospy.get_param("~min_y", 1034.0),
        max_y=rospy.get_param("~max_y", 1051.0),
        xy_resolution=rospy.get_param("~xy_resolution", 0.25),
        yaw_resolution_deg=rospy.get_param("~yaw_resolution_deg", 7.5),
        primitive_length=rospy.get_param("~primitive_length", 0.45),
        integration_step=rospy.get_param("~integration_step", 0.075),
        steer_sample_count=rospy.get_param("~steer_sample_count", 9),
        max_iterations=rospy.get_param("~max_iterations", 160000),
        ref_ds=rospy.get_param("~ref_ds", 0.10),
        max_ref_speed=rospy.get_param("~max_ref_speed", 0.55),
        min_segment_time=rospy.get_param("~min_segment_time", 2.5),
        wheel_base=rospy.get_param("~wheel_base", 2.70),
        front_overhang=rospy.get_param("~front_overhang", 0.865),
        rear_overhang=rospy.get_param("~rear_overhang", 0.865),
        vehicle_width=rospy.get_param("~vehicle_width", 1.825),
        max_steer_deg=rospy.get_param("~max_steer_deg", 36.25),
        collision_padding=rospy.get_param("~collision_padding", 0.02),
        drivable_padding=rospy.get_param("~drivable_padding", 0.00),
        slot_width=rospy.get_param("~slot_width", 2.20),
        slot_length=rospy.get_param("~slot_length", 4.40),
        goal_xy_tolerance=rospy.get_param("~goal_xy_tolerance", 0.35),
        goal_yaw_tolerance_deg=rospy.get_param("~goal_yaw_tolerance_deg", 10.0),
        reverse_penalty=rospy.get_param("~reverse_penalty", 1.01),
        gear_switch_penalty=rospy.get_param("~gear_switch_penalty", 1.20),
        steer_penalty=rospy.get_param("~steer_penalty", 0.12),
        steer_change_penalty=rospy.get_param("~steer_change_penalty", 0.22),
        distance_heuristic_weight=rospy.get_param("~distance_heuristic_weight", 1.05),
        yaw_heuristic_weight=rospy.get_param("~yaw_heuristic_weight", 0.70),
    )


def get_pose_param(rospy, name):
    return rospy.get_param("~" + name, DEFAULT_SCENARIO[name])


def make_slot_polygons(debug, cfg):
    """Return target, left, right parking slot rectangles in world coords for RViz."""
    ox, oy = debug["goal_body_center"]
    row_yaw = debug["row_yaw"]
    half_w = cfg.slot_width * 0.5
    half_l = cfg.slot_length * 0.5

    def slot_poly(center_r):
        local = [
            (center_r + half_w,  half_l),
            (center_r + half_w, -half_l),
            (center_r - half_w, -half_l),
            (center_r - half_w,  half_l),
        ]
        return [local_to_world(r, s, ox, oy, row_yaw) for r, s in local]

    # target, left adjacent, right adjacent
    return [slot_poly(0.0), slot_poly(-cfg.slot_width), slot_poly(cfg.slot_width)]


def build_ref_message(rospy, RefTrajectory, RefTrajectoryPointMsg, ref):
    msg = RefTrajectory()
    msg.header.stamp = rospy.Time.now()
    msg.header.frame_id = "map"
    for p in ref:
        pt = RefTrajectoryPointMsg()
        pt.t = p.t
        pt.x = p.x
        pt.y = p.y
        pt.yaw = p.yaw
        pt.s = p.s
        pt.v = p.v
        pt.a = p.a
        pt.curvature = p.curvature
        pt.steer = p.steer
        pt.gear = p.gear
        msg.points.append(pt)
    return msg




def _yaw_from_pose_msg(msg):
    q = msg.pose.orientation
    _, _, yaw = tf.transformations.euler_from_quaternion([q.x, q.y, q.z, q.w])
    return yaw


def wait_for_live_start_pose(rospy, timeout_sec=5.0):
    """Wait for /alpha_control/current_pose and return [x, y, yaw_deg], or None."""
    try:
        msg = rospy.wait_for_message('/alpha_control/current_pose', PoseStamped, timeout=timeout_sec)
        yaw = _yaw_from_pose_msg(msg)
        return [msg.pose.position.x, msg.pose.position.y, math.degrees(yaw)]
    except Exception as exc:
        rospy.logwarn("live_start_from_current_pose requested but /alpha_control/current_pose was not received: %s", str(exc))
        return None

def main():
    import rospy
    rospy.init_node("alpha_control_morai_fixed_parking_planner", anonymous=False)

    from alpha_control.msg import RefTrajectory, RefTrajectoryPoint as RefTrajectoryPointMsg

    ref_traj_pub = rospy.Publisher("/alpha_control/ref_trajectory", RefTrajectory, queue_size=1, latch=True)

    cfg = load_config_from_ros_params(rospy)

    start_pose_source = rospy.get_param("~start_pose_source", "live")  # live or fixed
    configured_start_pose = get_pose_param(rospy, "start_pose")
    start_pose = configured_start_pose
    if start_pose_source in ["live", "current", "ego"]:
        live_pose = wait_for_live_start_pose(rospy, timeout_sec=float(rospy.get_param("~live_start_timeout_sec", 5.0)))
        if live_pose is not None:
            start_pose = live_pose
            rospy.logwarn("Using LIVE Ego pose as Hybrid A* start: [%.3f, %.3f, %.2f deg]", start_pose[0], start_pose[1], start_pose[2])
        else:
            rospy.logwarn("Falling back to configured start_pose: %s", str(configured_start_pose))

    params = {
        "pose_origin": rospy.get_param("~scenario_pose_origin", "rear_axle"),
        "center_to_rear_axle": rospy.get_param("~center_to_rear_axle", cfg.vehicle_length * 0.5 - cfg.rear_overhang),
        "start_pose": start_pose,
        "goal_pose": get_pose_param(rospy, "goal_pose"),
        "left_obstacle": get_pose_param(rospy, "left_obstacle"),
        "right_obstacle": get_pose_param(rospy, "right_obstacle"),
        "parked_vehicle_length": rospy.get_param("~parked_vehicle_length", cfg.vehicle_length),
        "parked_vehicle_width": rospy.get_param("~parked_vehicle_width", cfg.vehicle_width),
        "slot_width": rospy.get_param("~slot_width", cfg.slot_width),
        "slot_length": rospy.get_param("~slot_length", cfg.slot_length),
        "slot_width_margin": rospy.get_param("~slot_width_margin", 0.12),
        "slot_length_margin": rospy.get_param("~slot_length_margin", 0.25),
        "aisle_half_width": rospy.get_param("~aisle_half_width", 2.15),
        "row_min": rospy.get_param("~row_min", -9.0),
        "row_max": rospy.get_param("~row_max", 9.0),
    }

    obstacles, drivable_area, start, goal, debug = make_morai_fixed_pose_scenario(params, cfg)

    # Auto-fit map boundary around drivable area, obstacles, start, and goal.
    pts = list(drivable_area.outer_polygon) + [(start[0], start[1]), (goal[0], goal[1])]
    for obs in obstacles:
        pts.extend(obs.polygon(0.3))
    xs = [p[0] for p in pts]
    ys = [p[1] for p in pts]
    cfg.min_x = min(xs) - 1.0
    cfg.max_x = max(xs) + 1.0
    cfg.min_y = min(ys) - 1.0
    cfg.max_y = max(ys) + 1.0

    planner = HybridAStarPlanner(obstacles, drivable_area, cfg)
    slot_polygons = make_slot_polygons(debug, cfg)
    viz = RvizVisualizer(planner, start, goal, slot_centers=[], slot_polygons=slot_polygons)

    rospy.sleep(0.8)
    viz.publish_static()

    rospy.loginfo("MORAI fixed scenario loaded")
    rospy.loginfo("scenario_pose_origin=%s start_pose_source=%s", params["pose_origin"], start_pose_source)
    rospy.loginfo("start rear axle: x=%.3f y=%.3f yaw=%.3f deg", start[0], start[1], math.degrees(start[2]))
    rospy.loginfo("goal  rear axle: x=%.3f y=%.3f yaw=%.3f deg", goal[0], goal[1], math.degrees(goal[2]))
    rospy.loginfo("goal body center for display/slot: x=%.3f y=%.3f", debug["goal_body_center"][0], debug["goal_body_center"][1])
    rospy.loginfo("left obstacle body center: x=%.3f y=%.3f", debug["left_body_center"][0], debug["left_body_center"][1])
    rospy.loginfo("right obstacle body center: x=%.3f y=%.3f", debug["right_body_center"][0], debug["right_body_center"][1])
    rospy.loginfo("start local(row,slot)=%s goal local=%s", str(debug["start_local"]), str(debug["goal_local"]))

    visualize_every_n = int(rospy.get_param("~visualize_every_n", 20))
    animation_dt = float(rospy.get_param("~animation_dt", 0.01))

    def callback(*args):
        viz.publish_search_step(*args)
        if animation_dt > 0.0:
            rospy.sleep(animation_dt)

    try:
        use_hybrid = rospy.get_param("~use_hybrid_astar", True)
        chain = None
        raw = None
        if use_hybrid:
            rospy.loginfo("Hybrid A* planning started for measured MORAI target pose")
            try:
                chain = planner.plan(start, goal, step_callback=callback, callback_every_n=visualize_every_n)
            except Exception as exc:
                rospy.logwarn("Hybrid A* raised exception: %s", str(exc))
                chain = None

        if chain is not None:
            raw = planner.chain_to_dense_path(chain)
            rospy.loginfo("Hybrid A* succeeded. raw path points=%d stats=%s", len(raw), str(planner.last_stats))
        else:
            if not rospy.get_param("~use_fallback_seed_on_fail", True):
                rospy.logerr("Hybrid A* failed and fallback is disabled.")
                return
            rospy.logwarn("Using MORAI fixed two-stage rear-parking seed path fallback.")
            raw = make_morai_fixed_seed_path(start, goal, debug["goal_body_center"], cfg)
            planner.last_stats = {
                "success": 0.5,
                "iterations": 0.0,
                "nodes": 0.0,
                "closed": 0.0,
                "time_sec": 0.0,
                "path_length": sum(math.hypot(b.x-a.x, b.y-a.y) for a, b in zip(raw[:-1], raw[1:])),
                "gear_changes": 1.0,
            }

        ref = ReferenceTrajectoryGenerator(cfg).generate(raw)
        csv_path = rospy.get_param("~ref_csv_path", os.path.expanduser("~/.ros/alpha_control_morai_fixed_ref_traj.csv"))
        write_ref_csv(csv_path, ref)

        ref_msg = build_ref_message(rospy, RefTrajectory, RefTrajectoryPointMsg, ref)
        ref_traj_pub.publish(ref_msg)
        viz.publish_raw_and_ref(raw, ref, csv_path)

        rospy.loginfo("Published /alpha_control/ref_trajectory with %d points", len(ref))
        rospy.loginfo("Reference CSV saved: %s", csv_path)
        rospy.spin()
    except Exception as exc:
        rospy.logerr("Exception: %s", str(exc))
        rospy.logerr(traceback.format_exc())


if __name__ == "__main__":
    main()
