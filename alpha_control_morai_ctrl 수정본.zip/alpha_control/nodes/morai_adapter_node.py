#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MORAI adapter for alpha_control with strong diagnostics and safe gear gating.

/Ego_topic -> /alpha_control/current_pose, /alpha_control/current_speed
/alpha_control/tracking_cmd -> /ctrl_cmd

Important behavior in this debug-safe version:
  1. The input /Ego_topic pose is treated as rear-axle pose by default.
  2. Gear service call is made using the actual MoraiEventCmdSrv request class,
     not by passing EventInfo directly. This avoids service-signature mismatch.
  3. If a reverse command is required but gear service is unavailable or fails,
     this adapter holds brake instead of sending positive velocity in Drive.
  4. Final MORAI control uses longlCmdType==1 only.
     accel/brake are used for longitudinal control; velocity mode is not used.
     This matches MORAI practice code better for low-speed parking and makes
     braking at stop/gear-change points reliable.
  5. Debug information is published to /alpha_control/morai_adapter_debug
     and /alpha_control/morai_adapter_debug_markers.
"""

import math
import time
import traceback

import rospy
import tf.transformations

from geometry_msgs.msg import PoseStamped, Point
from std_msgs.msg import Float64, String
from nav_msgs.msg import Path
from visualization_msgs.msg import Marker, MarkerArray

from morai_msgs.msg import CtrlCmd, EgoVehicleStatus

try:
    from morai_msgs.msg import EventInfo
    from morai_msgs.srv import MoraiEventCmdSrv
except Exception:
    EventInfo = None
    MoraiEventCmdSrv = None

from alpha_control.msg import TrackingCommand


def clip(v, lo, hi):
    return max(lo, min(hi, v))


def yaw_to_quat(yaw):
    return tf.transformations.quaternion_from_euler(0.0, 0.0, yaw)


class MoraiAdapterNode(object):
    def __init__(self):
        rospy.init_node("alpha_control_morai_adapter", anonymous=False)

        self.frame_id = rospy.get_param("~frame_id", "map")
        self.ego_topic = rospy.get_param("~ego_topic", "/Ego_topic")
        self.ctrl_topic = rospy.get_param("~ctrl_topic", "/ctrl_cmd")
        self.ctrl_topic_secondary = rospy.get_param("~ctrl_topic_secondary", "")
        self.current_pose_topic = rospy.get_param("~current_pose_topic", "/alpha_control/current_pose")
        self.current_speed_topic = rospy.get_param("~current_speed_topic", "/alpha_control/current_speed")
        self.tracking_cmd_topic = rospy.get_param("~tracking_cmd_topic", "/alpha_control/tracking_cmd")

        self.vehicle_length = float(rospy.get_param("~vehicle_length", 4.43))
        self.vehicle_width = float(rospy.get_param("~vehicle_width", 1.825))
        self.rear_overhang = float(rospy.get_param("~rear_overhang", 0.865))
        self.center_to_rear_axle = float(rospy.get_param("~center_to_rear_axle", self.vehicle_length * 0.5 - self.rear_overhang))
        self.morai_pose_origin = rospy.get_param("~morai_pose_origin", "rear_axle")  # rear_axle or center

        self.max_steer_deg = float(rospy.get_param("~max_steer_deg", 36.25))
        self.max_steer_rad = math.radians(self.max_steer_deg)
        self.use_front_steer_ratio = rospy.get_param("~use_front_steer_ratio", True)
        self.invert_steer_sign = rospy.get_param("~invert_steer_sign", True)
        # Some MORAI builds expose front_steer/rear_steer as normalized ratio,
        # while older teaching material uses steering rad. Keep this selectable
        # so we can diagnose steering-no-response quickly.
        self.front_steer_command_type = rospy.get_param("~front_steer_command_type", "ratio")  # ratio or rad
        self.ctrl_velocity_unit = rospy.get_param("~ctrl_velocity_unit", "kph")  # kept for debug display only
        self.ego_velocity_unit = rospy.get_param("~ego_velocity_unit", "mps")

        # Final MORAI mode for parking: always use longlCmdType==1.
        # MORAI practice code uses accel/brake with longlCmdType 1.
        # Velocity mode (2) can ignore brake and caused creeping/forward-only behavior.
        self.command_mode = int(rospy.get_param("~command_mode", 1))
        self.longitudinal_control_mode = rospy.get_param("~longitudinal_control_mode", "throttle_brake")

        self.max_cmd_speed_mps = float(rospy.get_param("~max_cmd_speed_mps", 0.65))
        self.min_cmd_speed_mps = float(rospy.get_param("~min_cmd_speed_mps", 0.08))
        self.max_accel_cmd = float(rospy.get_param("~max_accel_cmd", 0.45))
        self.min_accel_when_moving = float(rospy.get_param("~min_accel_when_moving", 0.05))
        self.max_brake_cmd = float(rospy.get_param("~max_brake_cmd", 1.0))
        # Safety stop thresholds. Previous versions clipped a zero target speed
        # to min_cmd_speed_mps, which made the vehicle keep creeping forward
        # at gear-change / stop points. Now zero means full stop.
        self.stop_speed_epsilon = float(rospy.get_param("~stop_speed_epsilon", 0.03))
        self.brake_cmd_threshold = float(rospy.get_param("~brake_cmd_threshold", 0.15))
        self.off_path_lateral_stop = float(rospy.get_param("~off_path_lateral_stop", 1.20))
        self.off_path_heading_stop_deg = float(rospy.get_param("~off_path_heading_stop_deg", 75.0))
        self.stop_on_goal = rospy.get_param("~stop_on_goal", True)
        self.control_start_delay_sec = float(rospy.get_param("~control_start_delay_sec", 5.0))

        # Safety: do not keep driving forward if reverse gear was not accepted.
        self.require_gear_success_for_motion = rospy.get_param("~require_gear_success_for_motion", True)
        self.allow_motion_without_gear_service = rospy.get_param("~allow_motion_without_gear_service", False)
        self.set_auto_mode_on_start = rospy.get_param("~set_auto_mode_on_start", True)
        self.ctrl_mode_retry_sec = float(rospy.get_param("~ctrl_mode_retry_sec", 1.0))
        self.auto_mode_candidates = self.parse_int_list(rospy.get_param("~auto_mode_candidates", "3,4"), [3, 4])
        self.event_ctrl_mode_for_gear = int(rospy.get_param("~event_ctrl_mode_for_gear", 4))
        self.require_ctrl_subscriber = rospy.get_param("~require_ctrl_subscriber", True)
        self.command_response_watchdog_sec = float(rospy.get_param("~command_response_watchdog_sec", 1.0))
        self.last_nonzero_cmd_time = 0.0
        self.last_ego_response_time = 0.0
        self.last_command_response_warning = ""
        self.last_ctrl_mode_request_time = 0.0
        self.gear_request_retry_sec = float(rospy.get_param("~gear_request_retry_sec", 0.35))
        self.debug_print_rate_sec = float(rospy.get_param("~debug_print_rate_sec", 1.0))

        self.first_cmd_wall_time = None
        self.latest_pose = None
        self.latest_ego_msg_time = None
        self.latest_ego_heading_deg = 0.0
        self.latest_ego_speed_mps = 0.0
        self.latest_ego_signed_speed_mps = 0.0
        self.prev_pose_for_speed = None  # (t, x, y, yaw) rear-axle pose
        self.latest_ego_front_steer_angle = None
        self.latest_ego_rear_steer_angle = None
        self.latest_ego_accel = None
        self.latest_ego_brake = None
        self.actual_path = Path()
        self.actual_path.header.frame_id = self.frame_id
        self.actual_path_max_len = int(rospy.get_param("~actual_path_max_len", 3000))

        self.gear_service_name = rospy.get_param("~gear_service_name", "/Service_MoraiEventCmd")
        self.enable_gear_service = rospy.get_param("~enable_gear_service", True)
        self.last_requested_gear = None
        self.last_confirmed_gear = None  # We cannot read actual gear from EgoVehicleStatus, so service success is treated as confirmation.
        self.last_gear_request_time = 0.0
        self.last_gear_error = ""
        self.last_ctrl_summary = "no ctrl yet"
        self.last_cmd = None

        self.pose_pub = rospy.Publisher(self.current_pose_topic, PoseStamped, queue_size=1)
        self.speed_pub = rospy.Publisher(self.current_speed_topic, Float64, queue_size=1)
        self.ctrl_pub = rospy.Publisher(self.ctrl_topic, CtrlCmd, queue_size=1)
        self.ctrl_pub_secondary = rospy.Publisher(self.ctrl_topic_secondary, CtrlCmd, queue_size=1) if self.ctrl_topic_secondary else None
        self.vehicle_marker_pub = rospy.Publisher("/alpha_control/vehicle_markers", MarkerArray, queue_size=1)
        self.actual_path_pub = rospy.Publisher("/alpha_control/actual_path", Path, queue_size=1)
        self.debug_pub = rospy.Publisher("/alpha_control/morai_adapter_debug", String, queue_size=1)
        self.debug_marker_pub = rospy.Publisher("/alpha_control/morai_adapter_debug_markers", MarkerArray, queue_size=1)

        rospy.Subscriber(self.ego_topic, EgoVehicleStatus, self.ego_cb, queue_size=1)
        rospy.Subscriber(self.tracking_cmd_topic, TrackingCommand, self.cmd_cb, queue_size=1)

        self.gear_srv = None
        self.gear_srv_request_fields = "unknown"
        if self.enable_gear_service and MoraiEventCmdSrv is not None:
            try:
                rospy.wait_for_service(self.gear_service_name, timeout=4.0)
                self.gear_srv = rospy.ServiceProxy(self.gear_service_name, MoraiEventCmdSrv)
                self.gear_srv_request_fields = str(MoraiEventCmdSrv._request_class.__slots__)
                rospy.loginfo("MORAI gear service connected: %s request_fields=%s", self.gear_service_name, self.gear_srv_request_fields)
                if self.set_auto_mode_on_start:
                    ok = self.request_all_auto_modes()
                    rospy.loginfo("AutoMode candidate request result: %s candidates=%s", ok, self.auto_mode_candidates)
            except Exception as exc:
                self.gear_srv = None
                self.last_gear_error = "gear service unavailable: %s" % str(exc)
                rospy.logwarn("MORAI gear service unavailable: %s", str(exc))

        self.timer = rospy.Timer(rospy.Duration(0.05), self.timer_cb)
        self.debug_timer = rospy.Timer(rospy.Duration(0.5), self.debug_timer_cb)
        rospy.loginfo("MORAI adapter started: ego=%s ctrl=%s secondary=%s", self.ego_topic, self.ctrl_topic, self.ctrl_topic_secondary)
        rospy.loginfo("Pose origin conversion: morai_pose_origin=%s center_to_rear_axle=%.3f", self.morai_pose_origin, self.center_to_rear_axle)

    @staticmethod
    def parse_int_list(value, default):
        try:
            if isinstance(value, (list, tuple)):
                return [int(v) for v in value]
            return [int(v.strip()) for v in str(value).split(',') if v.strip()]
        except Exception:
            return list(default)

    def ctrl_connection_count(self):
        primary = self.ctrl_pub.get_num_connections() if self.ctrl_pub is not None else 0
        secondary = self.ctrl_pub_secondary.get_num_connections() if self.ctrl_pub_secondary is not None else 0
        return primary, secondary


    def ego_cb(self, msg):
        x = msg.position.x
        y = msg.position.y
        yaw = math.radians(msg.heading) if hasattr(msg, "heading") else 0.0
        self.latest_ego_heading_deg = float(msg.heading) if hasattr(msg, "heading") else 0.0
        self.latest_ego_msg_time = rospy.Time.now()
        if hasattr(msg, "front_steer_angle"):
            self.latest_ego_front_steer_angle = msg.front_steer_angle
        elif hasattr(msg, "wheel_angle"):
            self.latest_ego_front_steer_angle = msg.wheel_angle
        if hasattr(msg, "rear_steer_angle"):
            self.latest_ego_rear_steer_angle = msg.rear_steer_angle
        if hasattr(msg, "accel"):
            self.latest_ego_accel = msg.accel
        if hasattr(msg, "brake"):
            self.latest_ego_brake = msg.brake

        if self.morai_pose_origin == "center":
            rear_x = x - self.center_to_rear_axle * math.cos(yaw)
            rear_y = y - self.center_to_rear_axle * math.sin(yaw)
        else:
            rear_x = x
            rear_y = y

        ps = PoseStamped()
        ps.header.stamp = rospy.Time.now()
        ps.header.frame_id = self.frame_id
        ps.pose.position.x = rear_x
        ps.pose.position.y = rear_y
        ps.pose.position.z = 0.0
        q = yaw_to_quat(yaw)
        ps.pose.orientation.x, ps.pose.orientation.y, ps.pose.orientation.z, ps.pose.orientation.w = q
        self.pose_pub.publish(ps)
        self.latest_pose = ps
        self.publish_vehicle_visualization(ps, yaw)

        speed = 0.0
        if hasattr(msg, "velocity"):
            speed = math.hypot(msg.velocity.x, msg.velocity.y)
        if self.ego_velocity_unit == "kph":
            speed /= 3.6
        self.latest_ego_speed_mps = speed

        # Publish signed rear-axle speed for the tracker. MORAI Ego velocity is
        # often magnitude-like in examples, while reverse parking needs the
        # sign. Estimate sign by projecting rear-axle displacement onto the
        # vehicle heading. This keeps PID behavior correct in R gear.
        signed_speed = speed
        now_sec = ps.header.stamp.to_sec() if ps.header.stamp != rospy.Time(0) else time.time()
        if self.prev_pose_for_speed is not None:
            prev_t, prev_x, prev_y, _prev_yaw = self.prev_pose_for_speed
            dt = max(now_sec - prev_t, 1e-3)
            dx = rear_x - prev_x
            dy = rear_y - prev_y
            projected = (dx * math.cos(yaw) + dy * math.sin(yaw)) / dt
            if abs(projected) > 0.02:
                signed_speed = projected
            else:
                signed_speed = 0.0 if speed < 0.03 else speed
        self.prev_pose_for_speed = (now_sec, rear_x, rear_y, yaw)
        self.latest_ego_signed_speed_mps = signed_speed
        self.speed_pub.publish(Float64(data=signed_speed))

    def publish_vehicle_visualization(self, ps, yaw):
        now = rospy.Time.now()
        ma = MarkerArray()

        body_center_offset = self.vehicle_length * 0.5 - self.rear_overhang
        cx = ps.pose.position.x + body_center_offset * math.cos(yaw)
        cy = ps.pose.position.y + body_center_offset * math.sin(yaw)

        body = Marker()
        body.header.frame_id = self.frame_id
        body.header.stamp = now
        body.ns = "morai_ego_body"
        body.id = 1
        body.type = Marker.CUBE
        body.action = Marker.ADD
        body.pose.position.x = cx
        body.pose.position.y = cy
        body.pose.position.z = 0.18
        q = yaw_to_quat(yaw)
        body.pose.orientation.x, body.pose.orientation.y, body.pose.orientation.z, body.pose.orientation.w = q
        body.scale.x = self.vehicle_length
        body.scale.y = self.vehicle_width
        body.scale.z = 0.36
        body.color.r = 0.0
        body.color.g = 0.9
        body.color.b = 1.0
        body.color.a = 0.55
        ma.markers.append(body)

        rear = Marker()
        rear.header.frame_id = self.frame_id
        rear.header.stamp = now
        rear.ns = "morai_rear_axle"
        rear.id = 2
        rear.type = Marker.SPHERE
        rear.action = Marker.ADD
        rear.pose.position.x = ps.pose.position.x
        rear.pose.position.y = ps.pose.position.y
        rear.pose.position.z = 0.25
        rear.pose.orientation.w = 1.0
        rear.scale.x = rear.scale.y = rear.scale.z = 0.35
        rear.color.r = 0.1
        rear.color.g = 1.0
        rear.color.b = 1.0
        rear.color.a = 1.0
        ma.markers.append(rear)
        self.vehicle_marker_pub.publish(ma)

        self.actual_path.header.stamp = now
        path_pose = PoseStamped()
        path_pose.header = self.actual_path.header
        path_pose.pose = ps.pose
        self.actual_path.poses.append(path_pose)
        if len(self.actual_path.poses) > self.actual_path_max_len:
            self.actual_path.poses = self.actual_path.poses[-self.actual_path_max_len:]
        self.actual_path_pub.publish(self.actual_path)

    def cmd_cb(self, msg):
        self.last_cmd = msg
        if self.first_cmd_wall_time is None:
            self.first_cmd_wall_time = time.time()
            rospy.loginfo("First tracking command received. Waiting %.1f sec before sending speed.", self.control_start_delay_sec)

    def _make_event_request(self, option, gear=None, ctrl_mode=None):
        """Build MoraiEventCmdSrv request robustly across MORAI msg versions."""
        if MoraiEventCmdSrv is None:
            return None
        req = MoraiEventCmdSrv._request_class()

        def fill_event_info(event):
            if hasattr(event, "option"):
                event.option = int(option)
            if gear is not None and hasattr(event, "gear"):
                event.gear = int(gear)
            if ctrl_mode is not None and hasattr(event, "ctrl_mode"):
                event.ctrl_mode = int(ctrl_mode)

        # Version A: request has field 'request' of type EventInfo.
        if hasattr(req, "request"):
            if EventInfo is not None:
                event = EventInfo()
            else:
                event = req.request
            fill_event_info(event)
            req.request = event
            return req

        # Version B: request itself has option/gear/ctrl_mode.
        fill_event_info(req)
        return req

    def _read_event_response_field(self, response, field_name):
        """Read fields from different MoraiEventCmdSrv response versions."""
        if response is None:
            return None
        if hasattr(response, field_name):
            return getattr(response, field_name)
        if hasattr(response, "response") and hasattr(response.response, field_name):
            return getattr(response.response, field_name)
        return None

    def _call_event_service(self, option, gear=None, ctrl_mode=None):
        """Call MORAI event service and return (ok, response)."""
        if self.gear_srv is None:
            self.last_gear_error = "gear service proxy is None"
            return False, None
        try:
            req = self._make_event_request(option=option, gear=gear, ctrl_mode=ctrl_mode)
            response = self.gear_srv(req)
            self.last_gear_error = ""
            return True, response
        except Exception as exc:
            self.last_gear_error = "%s\n%s" % (str(exc), traceback.format_exc(limit=1))
            rospy.logwarn_throttle(1.0, "MORAI event service call failed: %s", str(exc))
            return False, None

    def request_ctrl_mode(self, ctrl_mode):
        # option 1 = ctrl_mode. Different MORAI practice projects use different
        # ctrl_mode values around AutoMode/API mode, so this function is called
        # for every candidate in self.auto_mode_candidates.
        ok, response = self._call_event_service(option=1, ctrl_mode=ctrl_mode)
        resp_ctrl_mode = self._read_event_response_field(response, "ctrl_mode")
        if ok and resp_ctrl_mode is not None and int(resp_ctrl_mode) != int(ctrl_mode):
            self.last_gear_error = "ctrl_mode response mismatch: requested %s got %s" % (ctrl_mode, resp_ctrl_mode)
            rospy.logwarn_throttle(1.0, self.last_gear_error)
            return False
        return ok

    def request_all_auto_modes(self):
        ok_any = False
        for mode in self.auto_mode_candidates:
            ok_any = self.request_ctrl_mode(mode) or ok_any
        return ok_any

    def request_gear(self, gear):
        # MORAI gear: 1=P, 2=R, 3=N, 4=D
        now = time.time()
        self.last_requested_gear = gear
        if self.last_confirmed_gear == gear:
            return True
        if now - self.last_gear_request_time < self.gear_request_retry_sec:
            return False
        self.last_gear_request_time = now

        ok, response = self._call_event_service(option=2, gear=gear, ctrl_mode=self.event_ctrl_mode_for_gear)
        if not ok:
            return False

        # Some MORAI service versions include the selected gear in the response,
        # others only return a service success response. Check it when available.
        resp_gear = self._read_event_response_field(response, "gear")
        if resp_gear is not None and int(resp_gear) != int(gear):
            self.last_gear_error = "gear response mismatch: requested %s got %s" % (gear, resp_gear)
            rospy.logwarn_throttle(1.0, self.last_gear_error)
            return False

        self.last_confirmed_gear = gear
        rospy.loginfo("Requested/confirmed MORAI gear=%d", gear)
        return True

    def steering_rad_to_front_steer(self, steering_rad):
        """Convert tracker steering [rad] to the command expected by CtrlCmd.

        front_steer_command_type == "ratio": command in [-1, 1].
        front_steer_command_type == "rad"  : command in radians.
        """
        if self.max_steer_rad < 1e-6:
            return 0.0
        signed = -steering_rad if self.invert_steer_sign else steering_rad
        if self.front_steer_command_type == "rad":
            return clip(signed, -self.max_steer_rad, self.max_steer_rad)
        return clip(signed / self.max_steer_rad, -1.0, 1.0)

    def timer_cb(self, _event):
        if self.last_cmd is None:
            return
        tc = self.last_cmd

        # Keep requesting AutoMode periodically. In MORAI, if the vehicle is not
        # in AutoMode, /ctrl_cmd can be published correctly while accel/brake/steer
        # in /Ego_topic remain unchanged. This retry makes the problem visible
        # and reduces silent command-ignore cases.
        if self.set_auto_mode_on_start and self.enable_gear_service:
            now_wall = time.time()
            if now_wall - self.last_ctrl_mode_request_time > self.ctrl_mode_retry_sec:
                self.last_ctrl_mode_request_time = now_wall
                self.request_all_auto_modes()

        delay_active = False
        if self.first_cmd_wall_time is not None and self.control_start_delay_sec > 0.0:
            delay_active = (time.time() - self.first_cmd_wall_time) < self.control_start_delay_sec

        desired_gear = 2 if tc.gear < 0 else 4
        gear_ok = True
        if self.enable_gear_service:
            gear_ok = self.request_gear(desired_gear)
            if not gear_ok and self.last_confirmed_gear == desired_gear:
                gear_ok = True
        elif not self.allow_motion_without_gear_service:
            gear_ok = False

        primary_conn, secondary_conn = self.ctrl_connection_count()
        ctrl_has_subscriber = (primary_conn + secondary_conn) > 0

        ctrl = CtrlCmd()
        ctrl.longlCmdType = self.command_mode  # final mode: 1, accel/brake/throttle control
        ctrl.velocity = 0.0
        ctrl.acceleration = 0.0

        raw_target_speed = abs(float(tc.target_speed))
        raw_accel_cmd = float(getattr(tc, "accel_cmd", 0.0))
        raw_brake_cmd = float(getattr(tc, "brake_cmd", 0.0))
        lateral_error = abs(float(getattr(tc, "lateral_error", 0.0)))
        heading_error_deg = abs(math.degrees(float(getattr(tc, "heading_error", 0.0))))

        hold_reason = "moving"
        target_speed = 0.0
        accel = 0.0
        brake = 0.0

        if delay_active:
            brake = 1.0
            hold_reason = "start_delay"
        elif self.require_ctrl_subscriber and not ctrl_has_subscriber:
            brake = 1.0
            hold_reason = "NO_CTRL_SUBSCRIBER primary=%d secondary=%d" % (primary_conn, secondary_conn)
        elif self.stop_on_goal and tc.goal_reached:
            brake = 1.0
            hold_reason = "goal_reached"
        elif self.require_gear_success_for_motion and not gear_ok:
            brake = 1.0
            hold_reason = "waiting_gear_%s" % ("R" if desired_gear == 2 else "D")
        elif lateral_error > self.off_path_lateral_stop:
            brake = 1.0
            hold_reason = "OFF_PATH_LAT %.2fm" % lateral_error
        elif heading_error_deg > self.off_path_heading_stop_deg:
            brake = 1.0
            hold_reason = "OFF_PATH_YAW %.1fdeg" % heading_error_deg
        elif raw_brake_cmd > self.brake_cmd_threshold or raw_target_speed <= self.stop_speed_epsilon:
            brake = max(raw_brake_cmd, 1.0)
            hold_reason = "planned_stop_or_pid_brake"
        else:
            target_speed = clip(raw_target_speed, self.min_cmd_speed_mps, self.max_cmd_speed_mps)
            accel = clip(raw_accel_cmd, 0.0, self.max_accel_cmd)
            if accel < self.min_accel_when_moving:
                accel = self.min_accel_when_moving
            brake = 0.0
            hold_reason = "moving"

        # Final MORAI parking command policy:
        #   longlCmdType=1 always.
        #   D/R direction is selected by gear service.
        #   accel is positive in the selected gear, brake is used for stops.
        ctrl.accel = clip(accel, 0.0, self.max_accel_cmd)
        ctrl.brake = clip(brake, 0.0, self.max_brake_cmd)

        steering_out = 0.0
        if hasattr(ctrl, "front_steer"):
            steering_out = self.steering_rad_to_front_steer(tc.steering_rad)
            ctrl.front_steer = steering_out
            ctrl.rear_steer = 0.0
        elif hasattr(ctrl, "steering"):
            steering_out = -tc.steering_rad if self.invert_steer_sign else tc.steering_rad
            ctrl.steering = steering_out

        self.ctrl_pub.publish(ctrl)
        if self.ctrl_pub_secondary is not None:
            self.ctrl_pub_secondary.publish(ctrl)
        if ctrl.accel > 0.01 or ctrl.brake > 0.01 or abs(steering_out) > 0.05:
            self.last_nonzero_cmd_time = time.time()
        # Detect the most important failure mode from the latest logs: CtrlCmd is
        # published, but /Ego_topic accel/brake/front_steer_angle stay 0. This
        # means MORAI is not applying the command, usually due to wrong topic,
        # AutoMode/API mode, or message interpretation.
        ego_shows_response = False
        if self.latest_ego_front_steer_angle is not None and abs(self.latest_ego_front_steer_angle) > 1e-4:
            ego_shows_response = True
        if self.latest_ego_accel is not None and abs(self.latest_ego_accel) > 1e-4:
            ego_shows_response = True
        if self.latest_ego_brake is not None and abs(self.latest_ego_brake) > 1e-4:
            ego_shows_response = True
        if ego_shows_response:
            self.last_ego_response_time = time.time()
            self.last_command_response_warning = ""
        elif self.last_nonzero_cmd_time > 0 and time.time() - self.last_nonzero_cmd_time > self.command_response_watchdog_sec:
            self.last_command_response_warning = (
                "MORAI_NOT_APPLYING_CMD: CtrlCmd published but Ego accel/brake/steer remain zero. "
                "Check topic subscriber, AutoMode/API mode, and try ctrl_topic:=/ctrl_cmd or dual publish."
            )
        self.last_ctrl_summary = (
            "hold=%s mode=%d desired_gear=%s gear_ok=%s confirmed=%s ctrl_conn=%d/%d "
            "target_v=%.2fmps raw_v=%.2fmps accel=%.2f raw_accel=%.2f brake=%.2f raw_brake=%.2f "
            "lat=%.2fm yawerr=%.1fdeg vel_field=%.2f steer_type=%s steer_rad=%.3f steer_out=%.3f" % (
                hold_reason,
                ctrl.longlCmdType,
                "R" if desired_gear == 2 else "D",
                gear_ok,
                str(self.last_confirmed_gear),
                primary_conn,
                secondary_conn,
                target_speed,
                raw_target_speed,
                ctrl.accel,
                raw_accel_cmd,
                ctrl.brake,
                raw_brake_cmd,
                lateral_error,
                heading_error_deg,
                ctrl.velocity,
                self.front_steer_command_type,
                tc.steering_rad,
                steering_out,
            )
        )

    def debug_timer_cb(self, _event):
        cmd = self.last_cmd
        if cmd is None:
            txt = "MORAI_ADAPTER_DEBUG\ntracking_cmd: not received yet\nEgo topic: %s" % self.ego_topic
        else:
            txt = (
                "MORAI_ADAPTER_DEBUG\n"
                "tracking gear: %s  target_speed: %.3f  steer_rad: %.3f\n"
                "nearest/target: %d/%d  goal_reached: %s\n"
                "ego speed: %.3f m/s signed: %.3f m/s  heading: %.2f deg  ego_steer:%s accel:%s brake:%s\n"
                "gear service: %s  req_fields: %s\n"
                "last requested gear: %s  confirmed gear: %s\n"
                "ctrl: %s\n"
                "command response warning: %s\n"
                "last gear error: %s"
            ) % (
                "R" if cmd.gear < 0 else "D",
                cmd.target_speed,
                cmd.steering_rad,
                cmd.nearest_index,
                cmd.target_index,
                str(cmd.goal_reached),
                self.latest_ego_speed_mps,
                self.latest_ego_signed_speed_mps,
                self.latest_ego_heading_deg,
                "None" if self.latest_ego_front_steer_angle is None else ("%.4f" % self.latest_ego_front_steer_angle),
                "None" if self.latest_ego_accel is None else ("%.2f" % self.latest_ego_accel),
                "None" if self.latest_ego_brake is None else ("%.2f" % self.latest_ego_brake),
                "connected" if self.gear_srv is not None else "NONE",
                self.gear_srv_request_fields,
                str(self.last_requested_gear),
                str(self.last_confirmed_gear),
                self.last_ctrl_summary,
                self.last_command_response_warning[:220],
                self.last_gear_error[:180],
            )
        rospy.loginfo_throttle(self.debug_print_rate_sec, txt.replace("\n", " | "))
        self.debug_pub.publish(String(data=txt))
        self.publish_debug_marker(txt)

    def publish_debug_marker(self, txt):
        ma = MarkerArray()
        m = Marker()
        m.header.frame_id = self.frame_id
        m.header.stamp = rospy.Time.now()
        m.ns = "morai_adapter_debug_text"
        m.id = 1
        m.type = Marker.TEXT_VIEW_FACING
        m.action = Marker.ADD
        if self.latest_pose is not None:
            m.pose.position.x = self.latest_pose.pose.position.x + 2.0
            m.pose.position.y = self.latest_pose.pose.position.y + 2.0
        else:
            m.pose.position.x = 12.0
            m.pose.position.y = 1042.0
        m.pose.position.z = 1.2
        m.pose.orientation.w = 1.0
        m.scale.z = 0.28
        m.color.r = 1.0
        m.color.g = 0.9
        m.color.b = 0.1
        m.color.a = 1.0
        m.text = txt[:900]
        ma.markers.append(m)
        self.debug_marker_pub.publish(ma)


if __name__ == "__main__":
    try:
        node = MoraiAdapterNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
