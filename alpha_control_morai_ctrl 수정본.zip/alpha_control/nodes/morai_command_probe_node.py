#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MORAI low-level command probe.

This node is for diagnosing the exact problem seen in the logs:
CtrlCmd is published, but /Ego_topic accel/brake/front_steer_angle stay zero.

It does NOT run Hybrid A* or the parking controller. It only checks whether MORAI
actually accepts CtrlCmd on /ctrl_cmd.

Default behavior is conservative: brake-only test. Set active_drive_test:=true
only in an empty safe area to test accel/steer response.
"""

import math
import time
import rospy
from std_msgs.msg import String
from morai_msgs.msg import CtrlCmd, EgoVehicleStatus
try:
    from morai_msgs.msg import EventInfo
    from morai_msgs.srv import MoraiEventCmdSrv
except Exception:
    EventInfo = None
    MoraiEventCmdSrv = None


class MoraiCommandProbe(object):
    def __init__(self):
        rospy.init_node('morai_command_probe_node')
        self.ego_topic = rospy.get_param('~ego_topic', '/Ego_topic')
        self.primary_topic = rospy.get_param('~ctrl_topic', '/ctrl_cmd')
        self.secondary_topic = rospy.get_param('~ctrl_topic_secondary', '')
        self.active_drive_test = rospy.get_param('~active_drive_test', False)
        self.test_steer = float(rospy.get_param('~test_steer', 0.35))
        self.test_accel = float(rospy.get_param('~test_accel', 0.12))
        self.test_brake = float(rospy.get_param('~test_brake', 1.0))
        self.publish_rate_hz = float(rospy.get_param('~publish_rate_hz', 20.0))
        self.auto_mode_candidates = [int(x.strip()) for x in str(rospy.get_param('~auto_mode_candidates', '3,4')).split(',') if x.strip()]
        self.gear_service_name = rospy.get_param('~gear_service_name', '/Service_MoraiEventCmd')
        self.event_ctrl_mode_for_gear = int(rospy.get_param('~event_ctrl_mode_for_gear', 4))

        self.ego = None
        self.ego_count = 0
        self.pub_primary = rospy.Publisher(self.primary_topic, CtrlCmd, queue_size=1)
        self.pub_secondary = rospy.Publisher(self.secondary_topic, CtrlCmd, queue_size=1) if self.secondary_topic else None
        self.report_pub = rospy.Publisher('/alpha_control/morai_command_probe_report', String, queue_size=1, latch=True)
        rospy.Subscriber(self.ego_topic, EgoVehicleStatus, self.ego_cb, queue_size=1)

        self.srv = None
        if MoraiEventCmdSrv is not None:
            try:
                rospy.wait_for_service(self.gear_service_name, timeout=3.0)
                self.srv = rospy.ServiceProxy(self.gear_service_name, MoraiEventCmdSrv)
            except Exception as exc:
                rospy.logwarn('Event service unavailable: %s', exc)

    def ego_cb(self, msg):
        self.ego = msg
        self.ego_count += 1

    def make_event_req(self, option, gear=None, ctrl_mode=None):
        req = MoraiEventCmdSrv._request_class()
        def fill(event):
            if hasattr(event, 'option'):
                event.option = int(option)
            if gear is not None and hasattr(event, 'gear'):
                event.gear = int(gear)
            if ctrl_mode is not None and hasattr(event, 'ctrl_mode'):
                event.ctrl_mode = int(ctrl_mode)
        if hasattr(req, 'request'):
            event = EventInfo() if EventInfo is not None else req.request
            fill(event)
            req.request = event
        else:
            fill(req)
        return req

    def call_event(self, option, gear=None, ctrl_mode=None):
        if self.srv is None:
            return False, 'no_service'
        try:
            self.srv(self.make_event_req(option, gear=gear, ctrl_mode=ctrl_mode))
            return True, 'ok'
        except Exception as exc:
            return False, str(exc)

    def request_modes(self):
        out = []
        for mode in self.auto_mode_candidates:
            ok, msg = self.call_event(option=1, ctrl_mode=mode)
            out.append('ctrl_mode %s -> %s %s' % (mode, ok, msg))
        ok, msg = self.call_event(option=2, gear=4, ctrl_mode=self.event_ctrl_mode_for_gear)
        out.append('gear D(4) ctrl_mode=%s -> %s %s' % (self.event_ctrl_mode_for_gear, ok, msg))
        return out

    def publish_cmd(self, cmd):
        self.pub_primary.publish(cmd)
        if self.pub_secondary is not None:
            self.pub_secondary.publish(cmd)

    def snapshot(self):
        if self.ego is None:
            return None
        msg = self.ego
        speed = 0.0
        try:
            speed = math.hypot(msg.velocity.x, msg.velocity.y)
        except Exception:
            pass
        return {
            'x': getattr(msg.position, 'x', 0.0),
            'y': getattr(msg.position, 'y', 0.0),
            'heading': getattr(msg, 'heading', 0.0),
            'speed': speed,
            'front_steer_angle': getattr(msg, 'front_steer_angle', None),
            'accel': getattr(msg, 'accel', None),
            'brake': getattr(msg, 'brake', None),
        }

    def run_phase(self, name, duration, cmd):
        rate = rospy.Rate(self.publish_rate_hz)
        start = time.time()
        before = self.snapshot()
        while not rospy.is_shutdown() and time.time() - start < duration:
            self.publish_cmd(cmd)
            rate.sleep()
        after = self.snapshot()
        return name, before, after

    def run(self):
        rospy.loginfo('Waiting for Ego topic: %s', self.ego_topic)
        t0 = time.time()
        while self.ego is None and not rospy.is_shutdown() and time.time() - t0 < 5.0:
            rospy.sleep(0.05)
        mode_results = self.request_modes()
        rospy.sleep(0.5)

        phases = []
        # Phase 1: brake-only. This should be safe and must show deceleration if MORAI accepts commands.
        cmd = CtrlCmd()
        cmd.longlCmdType = 1
        cmd.accel = 0.0
        cmd.brake = self.test_brake
        if hasattr(cmd, 'front_steer'):
            cmd.front_steer = 0.0
            cmd.rear_steer = 0.0
        elif hasattr(cmd, 'steering'):
            cmd.steering = 0.0
        cmd.velocity = 0.0
        cmd.acceleration = 0.0
        phases.append(self.run_phase('BRAKE_ONLY', 2.0, cmd))

        # Optional active test: only in a clear area.
        if self.active_drive_test:
            cmd = CtrlCmd()
            cmd.longlCmdType = 1
            cmd.accel = self.test_accel
            cmd.brake = 0.0
            if hasattr(cmd, 'front_steer'):
                cmd.front_steer = self.test_steer
                cmd.rear_steer = 0.0
            elif hasattr(cmd, 'steering'):
                cmd.steering = self.test_steer
            cmd.velocity = 0.0
            cmd.acceleration = 0.0
            phases.append(self.run_phase('ACCEL_STEER_ACTIVE', 1.5, cmd))
            # Brake after active test.
            cmd = CtrlCmd(); cmd.longlCmdType = 1; cmd.accel = 0.0; cmd.brake = 1.0; cmd.velocity = 0.0; cmd.acceleration = 0.0
            if hasattr(cmd, 'front_steer'):
                cmd.front_steer = 0.0; cmd.rear_steer = 0.0
            elif hasattr(cmd, 'steering'):
                cmd.steering = 0.0
            phases.append(self.run_phase('FINAL_BRAKE', 2.0, cmd))

        primary_conn = self.pub_primary.get_num_connections()
        secondary_conn = self.pub_secondary.get_num_connections() if self.pub_secondary is not None else 0
        lines = []
        lines.append('MORAI_COMMAND_PROBE_REPORT')
        lines.append('topics: primary=%s conn=%d secondary=%s conn=%d' % (self.primary_topic, primary_conn, self.secondary_topic, secondary_conn))
        lines.append('ego_received=%d' % self.ego_count)
        lines.extend(mode_results)
        for name, before, after in phases:
            lines.append('%s before=%s after=%s' % (name, before, after))
        lines.append('INTERPRETATION:')
        if primary_conn + secondary_conn == 0:
            lines.append('- No subscribers on ctrl topics. MORAI is not listening to these topics.')
        lines.append('- If Ego accel/brake/front_steer_angle remain 0 and speed/heading do not respond, CtrlCmd is ignored: check AutoMode, ctrl topic, and message field convention.')
        lines.append('- If brake phase reduces speed, longitudinal command is applied. If active steer does not change heading/ego_steer, steering field convention/topic is wrong.')
        report = '\n'.join(lines)
        rospy.loginfo(report.replace('\n', ' | '))
        self.report_pub.publish(String(data=report))
        rospy.spin()

if __name__ == '__main__':
    MoraiCommandProbe().run()
