#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""MORAI parking debug monitor.

This node does not control the vehicle. It only checks whether the topics needed
for parking are alive and whether the command/gear direction is consistent.
"""

import math
import rospy
import tf.transformations
from std_msgs.msg import String, Float64
from geometry_msgs.msg import PoseStamped
from tf2_msgs.msg import TFMessage
from morai_msgs.msg import CtrlCmd, EgoVehicleStatus
from alpha_control.msg import TrackingCommand, RefTrajectory


def yaw_from_pose(ps):
    q = ps.pose.orientation
    return tf.transformations.euler_from_quaternion([q.x, q.y, q.z, q.w])[2]


class MoraiDebugNode(object):
    def __init__(self):
        rospy.init_node("alpha_control_morai_debug", anonymous=False)
        self.ctrl_topic = rospy.get_param("~ctrl_topic", "/ctrl_cmd")
        self.ego_topic = rospy.get_param("~ego_topic", "/Ego_topic")
        self.warn_tf_duplicates = rospy.get_param("~warn_tf_duplicates", True)

        self.last_ego = None
        self.last_pose = None
        self.prev_pose = None
        self.prev_pose_time = None
        self.last_cmd = None
        self.last_ctrl = None
        self.ref_count = 0
        self.ref_first_gear = 0
        self.ref_last_gear = 0
        self.tf_seen = {}
        self.tf_dup_count = 0
        self.tf_base_link_dup_count = 0

        rospy.Subscriber(self.ego_topic, EgoVehicleStatus, self.ego_cb, queue_size=1)
        rospy.Subscriber("/alpha_control/current_pose", PoseStamped, self.pose_cb, queue_size=1)
        rospy.Subscriber("/alpha_control/tracking_cmd", TrackingCommand, self.cmd_cb, queue_size=1)
        rospy.Subscriber(self.ctrl_topic, CtrlCmd, self.ctrl_cb, queue_size=1)
        rospy.Subscriber("/alpha_control/ref_trajectory", RefTrajectory, self.ref_cb, queue_size=1)
        rospy.Subscriber("/tf", TFMessage, self.tf_cb, queue_size=50)

        self.pub = rospy.Publisher("/alpha_control/debug_summary", String, queue_size=1)
        rospy.Timer(rospy.Duration(1.0), self.timer_cb)
        rospy.loginfo("MORAI debug node started.")

    def ego_cb(self, msg):
        self.last_ego = msg

    def pose_cb(self, msg):
        self.prev_pose = self.last_pose
        self.prev_pose_time = getattr(self.last_pose, "header", None).stamp if self.last_pose is not None else None
        self.last_pose = msg

    def cmd_cb(self, msg):
        self.last_cmd = msg

    def ctrl_cb(self, msg):
        self.last_ctrl = msg

    def ref_cb(self, msg):
        self.ref_count = len(msg.points)
        if msg.points:
            self.ref_first_gear = msg.points[0].gear
            self.ref_last_gear = msg.points[-1].gear

    def tf_cb(self, msg):
        for tr in msg.transforms:
            key = (tr.header.frame_id, tr.child_frame_id)
            stamp = tr.header.stamp.to_sec()
            prev = self.tf_seen.get(key)
            if prev is not None and abs(prev - stamp) < 1e-9:
                self.tf_dup_count += 1
                if tr.child_frame_id == "base_link":
                    self.tf_base_link_dup_count += 1
            self.tf_seen[key] = stamp

    def timer_cb(self, _event):
        lines = ["ALPHA_CONTROL_DEBUG_SUMMARY"]
        lines.append("ref points: %d first_gear:%s last_gear:%s" % (self.ref_count, self.ref_first_gear, self.ref_last_gear))

        if self.last_cmd is None:
            lines.append("tracking_cmd: NOT RECEIVED")
        else:
            lines.append("tracking_cmd: gear=%s target_v=%.3f steer=%.3f near/target=%d/%d goal=%s" % (
                "R" if self.last_cmd.gear < 0 else "D",
                self.last_cmd.target_speed,
                self.last_cmd.steering_rad,
                self.last_cmd.nearest_index,
                self.last_cmd.target_index,
                self.last_cmd.goal_reached,
            ))

        if self.last_ctrl is None:
            lines.append("ctrl_cmd: NOT PUBLISHED on %s" % self.ctrl_topic)
        else:
            steer_info = ""
            if hasattr(self.last_ctrl, "front_steer"):
                steer_info = "front_steer=%.3f rear_steer=%.3f" % (self.last_ctrl.front_steer, self.last_ctrl.rear_steer)
            elif hasattr(self.last_ctrl, "steering"):
                steer_info = "steering=%.3f" % self.last_ctrl.steering
            lines.append("ctrl_cmd: longl=%s accel=%.2f brake=%.2f vel=%.3f acceleration=%.3f %s" % (
                self.last_ctrl.longlCmdType,
                self.last_ctrl.accel,
                self.last_ctrl.brake,
                self.last_ctrl.velocity,
                self.last_ctrl.acceleration,
                steer_info,
            ))

        if self.last_ego is not None:
            sp = 0.0
            if hasattr(self.last_ego, "velocity"):
                sp = math.hypot(self.last_ego.velocity.x, self.last_ego.velocity.y)
            ego_steer = None
            if hasattr(self.last_ego, "front_steer_angle"):
                ego_steer = self.last_ego.front_steer_angle
            elif hasattr(self.last_ego, "wheel_angle"):
                ego_steer = self.last_ego.wheel_angle
            ego_accel = self.last_ego.accel if hasattr(self.last_ego, "accel") else None
            ego_brake = self.last_ego.brake if hasattr(self.last_ego, "brake") else None
            lines.append("ego: x=%.3f y=%.3f heading=%.2f speed=%.3f ego_steer=%s accel=%s brake=%s" % (
                self.last_ego.position.x,
                self.last_ego.position.y,
                self.last_ego.heading if hasattr(self.last_ego, "heading") else 0.0,
                sp,
                "None" if ego_steer is None else ("%.4f" % ego_steer),
                "None" if ego_accel is None else ("%.2f" % ego_accel),
                "None" if ego_brake is None else ("%.2f" % ego_brake),
            ))
        else:
            lines.append("ego: NOT RECEIVED from %s" % self.ego_topic)

        if self.last_pose is not None and self.prev_pose is not None:
            yaw = yaw_from_pose(self.last_pose)
            dx = self.last_pose.pose.position.x - self.prev_pose.pose.position.x
            dy = self.last_pose.pose.position.y - self.prev_pose.pose.position.y
            signed = dx * math.cos(yaw) + dy * math.sin(yaw)
            direction = "forward" if signed >= 0.0 else "reverse"
            lines.append("pose delta direction estimate: %s signed_delta=%.4f" % (direction, signed))

        if self.warn_tf_duplicates:
            lines.append("tf duplicate count: total=%d base_link=%d" % (self.tf_dup_count, self.tf_base_link_dup_count))
            if self.tf_base_link_dup_count > 0:
                lines.append("TF_REPEATED_DATA means duplicate/repeated map->base_link TF timestamps. It is RViz/TF warning, not Hybrid A* failure.")

        text = "\n".join(lines)
        self.pub.publish(String(data=text))
        rospy.loginfo_throttle(1.0, text.replace("\n", " | "))


if __name__ == "__main__":
    try:
        MoraiDebugNode()
        rospy.spin()
    except rospy.ROSInterruptException:
        pass
