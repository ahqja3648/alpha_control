# alpha_control

Autonomous parking control package for the Alpha Project.

This package keeps the same structure as the perception package style:

- `nodes/`: ROS wrappers only
- `core/`: ROS-independent planning/control/simulation logic
- `config/`: parameters and manual drivable-area settings
- `msgs/`: custom ROS messages
- `launch/`: runnable pipelines
- `rviz/`: RViz display configuration

## Current demo

RViz-only rear-parking pipeline:

1. manual drivable area
2. Hybrid-State A* planning
3. fallback rear-axle seed path if strict Hybrid A* fails
4. reference trajectory generation
5. Pure Pursuit + PID tracking
6. rear-axle kinematic bicycle virtual vehicle
7. RViz visualization

## Important assumptions

- Parking slot width: 2.2 m
- Parking slot length: 4.4 m
- Ego pose origin: rear axle center / `base_link`
- Vehicle model: rear-axle kinematic bicycle

## Run

```bash
cd ~/catkin_ws/src
unzip ~/Downloads/alpha_control_full_rear_axle.zip
cd ~/catkin_ws
catkin_make
source devel/setup.bash
roslaunch alpha_control parking_with_tracker.launch
```

RViz fixed frame: `map`.

Important topics:

- `/alpha_control/ref_trajectory`
- `/alpha_control/current_pose`
- `/alpha_control/current_speed`
- `/alpha_control/tracking_cmd`
- `/alpha_control/path_raw`
- `/alpha_control/path_ref`
- `/alpha_control/actual_path`
- `/alpha_control/static_markers`
- `/alpha_control/search_markers`
- `/alpha_control/final_markers`
- `/alpha_control/ref_markers`
- `/alpha_control/tracking_markers`
- `/alpha_control/vehicle_markers`


## MORAI fixed rear-axle pose version

This package version treats the user-provided MORAI start, goal, and adjacent obstacle poses as rear-axle-center poses. The planner, tracker, and MORAI adapter all use rear-axle-center pose. Parked vehicle obstacle poses are converted to body-center rectangles only for collision checking, because the internal RectObstacle type stores geometric center.

Nominal parking slot size is 2.2 m width x 4.4 m length.
