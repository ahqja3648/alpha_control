# MORAI Final Diagnosis Fix

This version changes the MORAI execution behavior based on the latest logs.

## Why the car kept moving forward

The logs showed that `/ctrl_cmd_0` was already publishing `longlCmdType=1, brake=1.0`, but the Ego vehicle had already drifted far away from the planned path. The controller correctly entered `OFF_PATH_LAT` stop mode, so it could only brake/coast; it could no longer follow the generated path.

Therefore this version plans from the **live Ego pose** by default instead of the old fixed start pose. If you want the old fixed start pose, launch with `start_pose_source:=fixed`.

## Additional fixes

- Signed speed is estimated from rear-axle pose delta and published to `/alpha_control/current_speed`.
- Gear-change handling now stops at the D/R boundary and then advances into the next segment after the vehicle is nearly stopped.
- Manual drivable area is automatically expanded to include the live start pose.
- AutoMode service request is retried periodically.
- Optional `ctrl_topic_secondary` can mirror commands to `/ctrl_cmd` during diagnosis.

## Recommended launch

```bash
roslaunch alpha_control parking_morai_fixed.launch start_pose_source:=live
```

If MORAI still ignores commands, test both command topics:

```bash
roslaunch alpha_control parking_morai_fixed.launch ctrl_topic:=/ctrl_cmd_0 ctrl_topic_secondary:=/ctrl_cmd
```

If steering does not appear in `/Ego_topic front_steer_angle`, try:

```bash
roslaunch alpha_control parking_morai_fixed.launch front_steer_command_type:=rad
```
