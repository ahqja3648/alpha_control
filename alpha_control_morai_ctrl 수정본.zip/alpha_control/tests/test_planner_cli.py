#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""ROS-independent quick planner test.
Run from package root:
  python3 tests/test_planner_cli.py
"""

import os
import sys

PKG_ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
if PKG_ROOT not in sys.path:
    sys.path.insert(0, PKG_ROOT)

from core.common.types import PlannerConfig
from core.planning.hybrid_astar import HybridAStarPlanner
from core.scenario.rear_parking import make_rear_parking_scenario
from core.trajectory.reference_trajectory import ReferenceTrajectoryGenerator


def main():
    obstacles, area, start, goal = make_rear_parking_scenario()
    cfg = PlannerConfig()
    planner = HybridAStarPlanner(obstacles, area, cfg)
    print("start valid:", planner.is_pose_valid(*start))
    print("goal valid :", planner.is_pose_valid(*goal))
    chain = planner.plan(start, goal)
    print("stats:", planner.last_stats)
    if chain is None:
        raise RuntimeError("planner failed")
    raw = planner.chain_to_dense_path(chain)
    ref = ReferenceTrajectoryGenerator(cfg).generate(raw)
    print("chain:", len(chain), "raw:", len(raw), "ref:", len(ref))
    print("last ref:", ref[-1] if ref else None)


if __name__ == "__main__":
    main()
